$(window).on("load", function() {
  $(".loader-wrapper").fadeOut("slow");
});
