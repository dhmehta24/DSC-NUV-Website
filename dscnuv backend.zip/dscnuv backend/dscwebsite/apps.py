from django.apps import AppConfig


class DscwebsiteConfig(AppConfig):
    name = 'dscwebsite'
